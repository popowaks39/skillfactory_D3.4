from django import template
 
register = template.Library()

BLACK_LIST = [
    'манги',
    'сезон',
    'Инстаграмм',
]


@register.filter()
def censor(text):
    cen_text = text
    slova = text.split()
    for i in slova:
        if i.lower() in BLACK_LIST:
            cen_text = cen_text.replace(i, i[0]+'*'*(len(i)-1))
    return cen_text